# Ironside Security Systems: website prototype

Single-page demo site for a fictional UK security installer (alarms, CCTV, video doorbells and access control, Leicester area).
It is one self-contained file: **`index.html`** (HTML, CSS and JavaScript, no build step, no dependencies).
Images are embedded in the file as base64. The originals are in `assets/` for reference or replacement.

## Run it
Open `index.html` in a browser, or serve the folder:

```bash
npx serve .
```

Google Fonts (Space Grotesk, Inter) load from the web. The page works without them using system fonts.

## Deploy
Any static host works: GitHub Pages, Netlify, Vercel or Cloudflare Pages. Publish the repository root.
For GitHub Pages, choose *Settings → Pages → Deploy from branch → main / (root)*.

## What is on the page
Hero with a photo background and a Google reviews image, What we do, Pricing, The Ironside Promise, Our work (before/after slider and reviews slider), FAQ, a final call to action and the footer.

- **One conversion goal:** "Get Your Free Quote". Outside the footer there are two buttons (hero and bottom of the page). Both open a 4-step popup that moves on automatically after each tap.
- **Floating contact:** a WhatsApp "Contact us" button on screens 768px and wider. On phones, a small phone icon in the footer corner and a floating quote button that appears while the footer is on screen.
- The quote popup is demo-only: it waits about 0.9 seconds, shows a fake reference and sends or stores nothing.

## Editing
Content lives in constants near the top of the `<script>`: `SITE`, `SERVICES`, `TIERS`, `GUARANTEES`, `REVIEWS`, `FAQS`, `BEFORE_AFTER`, `AREAS`.
Contact number, WhatsApp number and email are in `SITE`.

## Before using for a real client
See `PLACEHOLDERS.md`.
