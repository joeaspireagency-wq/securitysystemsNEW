# PLACEHOLDERS.md: items to replace before real use

This is a fictional demo. Elements that are placeholders carry a `data-placeholder` attribute in `index.html` (search for it).

| Area | Status |
|---|---|
| Business details | Name "Ironside Security Systems", owner "Gareth Whitlock", address (Unit 4, Welford Trade Park, LE4), email `@ironsidesecurity.example`, founded 2011 are invented. Phone and WhatsApp number are **+44 7340 843573** (supplied by the user): confirm it is correct. |
| Photos | Hero background photo, owner photo and the two before/after photos are user-supplied. The owner and before/after photos look AI-generated. Confirm rights, and use real photos of the real business and projects before launch. |
| Google reviews image | User-supplied image in the hero. It reads "Rating and count not yet verified" and shows 214 reviews, while the reviews slider and page data (JSON-LD) use the figures in `SITE`. Replace with a verified rating and make the figures match. |
| Prices | £495 / £1,295 / £2,450 "from" prices and the £1,950 + VAT business price are invented. |
| Guarantees | Free survey, fixed price, 5-year workmanship, 30-day handover, tidy fitting, honest advice: need real written terms. |
| Reviews | The six customer reviews and names are invented. |
| Before/after | The project details table is invented. |
| Legal | "ICO reg. no. [placeholder]" and "Company no. [placeholder]" in the footer. No Privacy or Cookies pages exist. |
| Coverage | Postcode prefixes LE, NN, NG, CV, DE (`SITE.coverage`) are examples. |
| Quote popup | Demo transport only: nothing is sent or stored. |
| WhatsApp icon | Third-party brand mark: follow WhatsApp brand guidelines. |
| Accreditation | No NSI, SSAIB, SbD or TrustMark membership is claimed. The badges were removed. Add only real memberships. |

## Wiring a real quote form
Implement a `QuoteTransport` (`send(req) => Promise<{reference}>`) for your form provider (for example Web3Forms or Formspree, following their official docs), then pass it to `submitQuote(input, transport)`. The popup UI does not change.
